### >>> software compilation
setwd("/home/yhw/AfterChat")
library("devtools")
devtools::document()
devtools::build()
remove.packages("AfterChat", lib="~/software/anaconda3/envs/rstudio-4.2.3/lib/R/library")
install.packages("/home/yhw/AfterChat_0.1.0.tar.gz", repos = NULL, type = "source")


### >>> load testing data
library("SeuratData")
data("pbmc3k")
library("Seurat")
test <- readRDS("/home/yhw/bioinfo/project-mine/MultiOmics/R/RDS/Seurat_hs_embryo_hindbrain.rds")
library("AfterChat")
edit(netClustering)

### >>> decoupleR analysis
act <- Pipe.decoupleR(sr.obj = pbmc3k[,sample(1:ncol(pbmc3k), 100)], species = "human")
act <- Pipe.decoupleR(sr.obj = test, species = "human")


### >>> SCENIC results
auc.mtx <- read.table("/home/yhw/bioinfo/project-mine/MultiOmics/R/RDS/SCENIC/hs_hindbrain/pySCENIC_auc_mtx.csv", sep = ",", header = T)
colnames(auc.mtx) <- gsub("\\.\\.\\.", "", colnames(auc.mtx))
auc.mtx$Cell <- test$CellType.sub
colnames(auc.mtx) <- gsub("\\.", "-", colnames(auc.mtx))


### >>> Signac analysis
library(Signac)
library(Seurat)
library(JASPAR2020)
library(TFBSTools)
pfm <- getMatrixSet(
  x = JASPAR2020,
  opts = list(collection = "CORE", tax_group = 'vertebrates', all_versions = FALSE)
)
hs.embryo <- readRDS("/home/yhw/bioinfo/project-mine/MultiOmics/R/RDS/hs.embryo.final.version.rds")
DefaultAssay(hs.embryo) <- "ATAC"
# call peaks using MACS2
peaks <- CallPeaks(hs.embryo, macs2.path = "/home/yhw/software/anaconda3/envs/dna.p37/bin/macs2")
# remove peaks on nonstandard chromosomes and in genomic blacklist regions
peaks <- keepStandardChromosomes(peaks, pruning.mode = "coarse")
peaks <- subsetByOverlaps(x = peaks, ranges = blacklist_hg38_unified, invert = TRUE)
# quantify counts in each peak
macs2_counts <- FeatureMatrix(
  fragments = Fragments(hs.embryo),
  features = peaks,
  cells = colnames(hs.embryo)
)
# create a new assay using the MACS2 peak set and add it to the Seurat object
annotation <- readRDS("/home/yhw/bioinfo/project-mine/MultiOmics/R/RDS/hg38.gene.annotation.rds")
fragpath <- list.files("/home/yhw/bioinfo/project-mine/MultiOmics", "atac_fragments.tsv.gz$", recursive = T, full.names = T)
hs.embryo[["peaks"]] <- CreateChromatinAssay(
  counts = macs2_counts,
  annotation = annotation
)
DefaultAssay(hs.embryo) <- "peaks"
hs.embryo <- FindTopFeatures(hs.embryo, min.cutoff = 5)
hs.embryo <- RunTFIDF(hs.embryo)
hs.embryo <- RunSVD(hs.embryo)
hs.embryo
# add motif information
library(BSgenome.Hsapiens.UCSC.hg38)
hs.embryo <- AddMotifs(
  object = hs.embryo,
  genome = BSgenome.Hsapiens.UCSC.hg38,
  pfm = pfm
)
hs.embryo <- RunChromVAR(
  object = hs.embryo,
  genome = BSgenome.Hsapiens.UCSC.hg38
)
DefaultAssay(hs.embryo) <- 'chromvar'
# look at the activity of Mef2c
grep("MA0712", rownames(hs.embryo), value = T)
p1 <- DimPlot(hs.embryo, label = TRUE, pt.size = 0.1, group.by = "SuperCluster") + NoLegend()
p2 <- FeaturePlot(
  object = hs.embryo,
  features = "MA0069.1",
  min.cutoff = 'q50',
  max.cutoff = 'q90',
  pt.size = 0.1
)
p1 + p2
signac <- GetTfAct(sc.obj = hs.embryo, tf.format = "jaspar.id",
                   filter.data = T, filter.by = "CellType.sub",
                   filter.terms = c("floor plate","roof plate",
                                    "p0.rhombomere","p1.rhombomere","p2.rhombomere",
                                    "pA1","pA2","pA3","pB1"))


### >>> CellChat analysis
library("CellChat")
db <- CellChatDB.human
ct <- Pipe.CellChat(sc.obj = test, cell.db = db,
                    group.by = "CellType.sub", split.by = NULL,
                    filter.data = T, filter.by = "CellType.sub",
                    filter.terms = c("floor plate","roof plate",
                                     "p0.rhombomere","p1.rhombomere","p2.rhombomere",
                                     "pA1","pA2","pA3","pB1"))
scale.f1 <- CalNormFactor(tf.data = auc.mtx[,-1], ave.method = "all", scale.data = T,
                          scale.method = c("range-01"), threshold = 0.5,
                          genelist = c("OLIG3","MSX1","MSX2","SP5","LMX1A","SMAD1","SMAD4","SMAD5"),
                          group.info = as.character(test$CellType.sub))
scale.f1$Ensembl.Mean[levels(ct$Sample@idents)]


scale.f2 <- CalNormFactor(tf.data = auc.mtx[,-1], ave.method = "all", scale.data = T,
                          scale.method = c("range-01"), threshold = 0.5,
                          genelist = c("DBX1","DBX2","NKX6-2","PAX6","GLI1"),
                          group.info = as.character(test$CellType.sub))
scale.f2$Ensembl.Mean[levels(ct$Sample@idents)]
scale.f2 <- CalNormFactor(tf.data = signac$TFact, ave.method = "all", scale.data = T,
                          scale.method = c("range-01"), threshold = 0.65,
                          genelist = c("MA0675.1","MA0069.1","MA1990.1"),
                          group.info = as.character(signac$GroupInfo))
scale.f2$Ensembl.Mean[levels(ct$Sample@idents)]


scale.fs <- list(BMP = scale.f1$Ensembl.Mean,
                 WNT = scale.f1$Ensembl.Mean,
                 HH = scale.f2$Ensembl.Mean)


### >>> adjust probalitity and pvalue
ct$Sample <- AdjustProPval(ct.obj = ct$Sample, type = "truncatedMean", trim = 0.1,
                           scale.factor = scale.fs, scale.path = names(scale.fs))


### >>> CellChat downstream analysis
AfterChat::PathCentrality(ct.obj = ct$Sample, outdir = "~/test", file.prefix = "Sample")
AfterChat::PathClustering(ct.obj = ct$Sample, outdir = "~/test", file.prefix = "Sample")
AfterChat::PathInteracion(ct.obj = ct$Sample, outdir = "~/test", file.prefix = "Sample")
AfterChat::LRsContribution(ct.obj = ct$Sample, outdir = "~/test", file.prefix = "Sample")
AfterChat::LRsInteraction(ct.obj = ct$Sample, outdir = "~/test", file.prefix = "Sample",
                          cell.source = c("floor plate","roof plate"),
                          cell.target = c("p0.rhombomere","p1.rhombomere","p2.rhombomere",
                                          "pA1","pA2","pA3","pB1"))


### >>> load testing data
save.image("/home/yhw/AfterChat_testing.RData")
load("/home/yhw/AfterChat_testing.RData")
