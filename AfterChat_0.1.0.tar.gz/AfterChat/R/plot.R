#' Examine if signaling pathways have significant interactions.
#'
#' This function can judge whether signaling pathways have significant interactions,
#' which is the key to batch drawing!
#'
#'
#' @param ct.obj A CellChat object.
#' @param signaling Name of signaling pathway.
#' @param thresh Pvalue threshold.
#'
#' @importFrom CellChat searchPair
#'
#' @return TRUE or FALSE.
#' @export
#'
CheckPathway <- function(ct.obj, signaling = NULL, thresh = 0.05) {
  # - 1. check parameters
  if (is.null(signaling)) {
    stop("[Error] Signaling pathway is absent !!!")
  }

  # - 2. calculating...
  pairLR <- searchPair(
    signaling = signaling, pairLR.use = ct.obj@LR$LRsig,
    key = "pathway_name", matching.exact = T, pair.only = T
  )
  net <- ct.obj@net
  pairLR.use.name <- dimnames(net$prob)[[3]]
  pairLR.name <- intersect(rownames(pairLR), pairLR.use.name)
  pairLR <- pairLR[pairLR.name, ]
  prob <- net$prob
  pval <- net$pval
  prob[pval > thresh] <- 0
  if (length(pairLR.name) > 1) {
    pairLR.name.use <- pairLR.name[apply(prob[, , pairLR.name], 3, sum) != 0]
  } else {
    pairLR.name.use <- pairLR.name[sum(prob[, , pairLR.name]) != 0]
  }

  # - 3. return data
  if (length(pairLR.name.use) == 0) {
    return(FALSE)
  } else {
    return(TRUE)
  }
}
#' Draw cell-cell communication network of each signaling pathway in batches.
#'
#' This function uses the "netVisual_aggregate" function to automatically draw
#' circle plot of each signaling pathway. The contact strength of all interactions
#' in each signaling pathway whill be aggregated.
#'
#' @param ct.obj A CellChat object.
#' @param outdir Directory to save files.
#' @param file.prefix Prefix of output files.
#'
#' @importFrom CellChat netVisual_aggregate
#' @importFrom CellChat netVisual_heatmap
#'
#' @return Local pdf files.
#' @export
#'
PathInteracion <- function(ct.obj, outdir, file.prefix = "Sample") {
  # - 1. general setting
  cell.db <- ct.obj@DB$interaction
  pathways.show <- unique(cell.db$pathway_name)
  cellchat.out <- paste0(outdir, "/Pathway_interaction")
  if (!dir.exists(cellchat.out)) {
    dir.create(cellchat.out, recursive = T)
  }

  # - 2. plotting each pathway interaction circle, chord plot and heatmap
  for (p in pathways.show) {
    path.exist <- length(grep(paste("^", p, "$", sep = ""), unique(ct.obj@LR$LRsig$pathway_name))) != 0
    if (isTRUE(path.exist)) {
      path.sig <- CheckPathway(ct.obj, signaling = p, thresh = 0.05)
    } else {
      path.sig <- FALSE
    }
    if (isTRUE(path.exist) & isTRUE(path.sig)) {
      out.p <- file.path(cellchat.out, paste0(file.prefix, "_signal_pathway_", p, "_interaction_circle_plot.pdf"))
      pdf(out.p, width = 6, height = 6)
      print(netVisual_aggregate(ct.obj, signaling = p, layout = "circle"))
      dev.off()
      #out.p <- file.path(cellchat.out, paste0(file.prefix, "_signal_pathway_", p, "_interaction_chord_plot.pdf"))
      #pdf(out.p, width = 6, height = 6)
      #print(netVisual_aggregate(ct.obj, signaling = p, layout = "chord"))
      #dev.off()
      out.p <- file.path(cellchat.out, paste0(file.prefix, "_signal_pathway_", p, "_interaction_heatmap_plot.pdf"))
      pdf(out.p, width = 6, height = 6)
      print(netVisual_heatmap(ct.obj, signaling = p, color.heatmap = "Greens"))
      dev.off()
    } else {
      print("[Warning] Pathway not found or is not significant !!!")
    }
  }
}
#' Perform network centrality analysis of pathway and visualize results in batch.
#'
#' This function uses the "netAnalysis_signalingRole"/netAnalysis_signalingRole"-related functions
#' to identify of dominant senders, receivers, mediators and influencers in each pathway.
#'
#' @inheritParams PathInteracion
#'
#' @importFrom CellChat netAnalysis_computeCentrality
#' @importFrom CellChat netAnalysis_signalingRole_scatter
#' @importFrom CellChat netAnalysis_signalingRole_heatmap
#' @importFrom CellChat netAnalysis_signalingRole_network
#' @importFrom CellChat netAnalysis_signalingRole_scatter
#'
#' @return Local pdf files.
#' @export
#'
PathCentrality <- function(ct.obj, outdir, file.prefix = "Sample") {
  # - 1. general setting
  cell.db <- ct.obj@DB$interaction
  pathways.show <- unique(cell.db$pathway_name)
  cellchat.out <- paste0(outdir, "/Pathway_centrality")
  if (!dir.exists(cellchat.out)) {
    dir.create(cellchat.out, recursive = T)
  }

  # - 2. calculate centrality
  ct.obj <- ct.obj %>% netAnalysis_computeCentrality(slot.name = "netP")

  # - 3. plotting
  # 2D visualization of dominant senders (sources) and receivers (targets): all pathway
  out.p <- file.path(cellchat.out, paste0(file.prefix, "_dominant_senders_and_receivers_dotplot.pdf"))
  pdf(out.p, width = 6, height = 5)
  print(netAnalysis_signalingRole_scatter(ct.obj))
  dev.off()
  # Signaling role analysis on the aggregated cell-cell communication network from all signaling pathways
  out.p <- file.path(cellchat.out, paste0(file.prefix, "_dominant_senders_and_receivers_heatmap.pdf"))
  pdf(out.p, width = 12, height = 12)
  p1 <- netAnalysis_signalingRole_heatmap(ct.obj, pattern = "outgoing")
  p2 <- netAnalysis_signalingRole_heatmap(ct.obj, pattern = "incoming")
  print(p1 + p2)
  dev.off()
  for (p in pathways.show) {
    path.exist <- p %in% ct.obj@LR$LRsig$pathway_name
    path.sig <- p %in% names(slot(ct.obj, "netP")$centr)
    if (path.exist & path.sig) {
      # network centrality scores
      out.p <- file.path(cellchat.out, paste0(file.prefix, "_signal_pathway_", p, "_signaling_role_plot.pdf"))
      pdf(out.p, width = 6, height = 5)
      print(netAnalysis_signalingRole_network(ct.obj, signaling = p, width = 8, height = 2.5, font.size = 10))
      dev.off()
      # dominant senders (sources) and receivers (targets)
      out.p <- file.path(cellchat.out, paste0(file.prefix, "_signal_pathway_", p, "_dominant_senders_and_receivers_dotplot.pdf"))
      pdf(out.p, width = 6, height = 6)
      print(netAnalysis_signalingRole_scatter(ct.obj), signaling = p)
      dev.off()
    } else {
      print("[Warning] Pathway not found or is not significant !!!")
    }
  }
}
#' Select the number of the patterns for running 'identifyCommunicationPatterns'.
#'
#' This function is adapted from "selectK" function in CellChat package.
#'
#' @param ct.obj A CellChat object.
#' @param slot.name The slot name in CellChat object.
#' @param pattern "outgoing" or "incoming".
#' @param ... Other arguments passed on to "selectK" function.
#'
#' @importFrom methods slot
#' @import NMF
#' @import ggplot2
#'
#' @return Dataframe.
#' @export
#'
CellChat.selectK <- function(ct.obj, slot.name = "netP", pattern = c("outgoing", "incoming"),
                             title.name = NULL, do.facet = TRUE, k.range = seq(2, 10), nrun = 30, seed.use = 10) {

  pattern <- match.arg(pattern)
  prob <- methods::slot(ct.obj, slot.name)$prob
  if (pattern == "outgoing") {
    data_sender <- apply(prob, c(1, 3), sum)
    data_sender <- sweep(data_sender, 2L, apply(
      data_sender,
      2, function(x) max(x, na.rm = TRUE)
    ), "/", check.margin = FALSE)
    data0 <- as.matrix(data_sender)
  } else if (pattern == "incoming") {
    data_receiver <- apply(prob, c(2, 3), sum)
    data_receiver <- sweep(data_receiver, 2L, apply(
      data_receiver,
      2, function(x) max(x, na.rm = TRUE)
    ), "/", check.margin = FALSE)
    data0 <- as.matrix(data_receiver)
  }
  options(warn = -1)
  data <- data0
  data <- data[rowSums(data) != 0, ]
  if (is.null(title.name)) {
    title.name <- paste0(pattern, " signaling \n")
  }
  res <- NMF::nmfEstimateRank(data,
    range = k.range, method = "lee",
    nrun = nrun, seed = seed.use
  )
  df1 <- data.frame(
    k = res$measures$rank, score = res$measures$cophenetic,
    Measure = "Cophenetic"
  )
  df2 <- data.frame(
    k = res$measures$rank, score = res$measures$silhouette.consensus,
    Measure = "Silhouette"
  )
  df <- rbind(df1, df2)
  return(df)
}
#' Clustering analysis of signaling pathway and visualize results.
#'
#' This function uses the "identifyCommunicationPatterns" function in CellChat
#' package to identify general communication patterns. Meanwhile, is also uses
#' the "computeNetSimilarity" function to compute signaling network similarity.
#'
#' @inheritParams PathInteracion
#'
#' @importFrom CellChat identifyCommunicationPatterns
#' @importFrom CellChat netAnalysis_river
#' @importFrom CellChat computeNetSimilarity
#' @importFrom CellChat netEmbedding
#' @importFrom CellChat netClustering
#' @importFrom CellChat netVisual_embedding
#' @importFrom methods slot
#' @importFrom stats cutree dist hclust
#' @importFrom grDevices colorRampPalette
#' @importFrom RColorBrewer brewer.pal
#' @import ggalluvial
#' @import NMF
#' @importFrom ggplot2 geom_text scale_x_discrete scale_fill_manual theme ggtitle
#' @importFrom cowplot plot_grid ggdraw draw_label
#'
#' @return Local pdf files.
#' @export
#'
PathClustering <- function(ct.obj, outdir, file.prefix = "Sample") {
  # - 1. general setting
  cellchat.out <- paste0(outdir, "/Path_clustering")
  if (!dir.exists(cellchat.out)) {
    dir.create(cellchat.out, recursive = T)
  }

  # - 2. visualize outgoing communication pattern of secreting cells
  nPatterns <- CellChat.selectK(ct.obj, pattern = "outgoing")
  nPatterns <- grep(TRUE, diff(subset(nPatterns, Measure == "Cophenetic")$score) < 0)[1] + 1
  out.p <- file.path(cellchat.out, paste0(file.prefix, "_outgoing_communication_pattern_heatmap.pdf"))
  pdf(out.p, width = 8, height = 10)
  ct.obj <- identifyCommunicationPatterns(ct.obj, pattern = "outgoing", k = nPatterns)
  dev.off()
  out.p <- file.path(cellchat.out, paste0(file.prefix, "_outgoing_communication_pattern_river_plot.pdf"))
  pdf(out.p, width = 6, height = 10)
  print(netAnalysis_river(ct.obj, pattern = "outgoing"))
  dev.off()

  # - 3. visualize ingoing communication pattern of secreting cells
  nPatterns <- CellChat.selectK(ct.obj, pattern = "incoming")
  nPatterns <- grep(TRUE, diff(subset(nPatterns, Measure == "Cophenetic")$score) < 0)[1] + 1
  out.p <- file.path(cellchat.out, paste0(file.prefix, "_incoming_communication_pattern_heatmap.pdf"))
  pdf(out.p, width = 8, height = 10)
  ct.obj <- identifyCommunicationPatterns(ct.obj, pattern = "incoming", k = nPatterns)
  dev.off()
  out.p <- file.path(cellchat.out, paste0(file.prefix, "_incoming_communication_pattern_river_plot.pdf"))
  pdf(out.p, width = 6, height = 10)
  print(netAnalysis_river(ct.obj, pattern = "incoming"))
  dev.off()

  # - 4. functional similarity
  ct.obj <- computeNetSimilarity(ct.obj, type = "functional")
  ct.obj <- netEmbedding(ct.obj, type = "functional", umap.method = "uwot")
  ct.obj <- netClustering.update(ct.obj, type = "functional")
  out.p <- file.path(cellchat.out, paste0(file.prefix, "_functional_similarity_scatter_plot.pdf"))
  pdf(out.p, width = 6, height = 4)
  print(netVisual_embedding(ct.obj, type = "functional", label.size = 3))
  dev.off()

  # - 5. structural similarity
  ct.obj <- computeNetSimilarity(ct.obj, type = "structural")
  ct.obj <- netEmbedding(ct.obj, type = "structural", umap.method = "uwot")
  ct.obj <- netClustering.update(ct.obj, type = "structural")
  out.p <- file.path(cellchat.out, paste0(file.prefix, "_structural_similarity_scatter_plot.pdf"))
  pdf(out.p, width = 6, height = 4)
  print(netVisual_embedding(ct.obj, type = "structural", label.size = 3))
  dev.off()
}
#' Examine if signaling pathways have significant links from sources to targets.
#'
#' This function can judge whether signaling pathways have significant links,
#' which is the key to batch drawing!
#'
#'
#' @param ct.obj A CellChat object.
#' @param signaling Name of signaling pathway.
#' @param thresh Pvalue threshold.
#'
#' @importFrom reshape2 melt
#' @importFrom dplyr select group_by summarize
#' @importFrom stringr str_split
#'
#' @return TRUE or FALSE.
#' @export
#'
CheckLinks <- function(object, slot.name = "net", signaling = NULL, net = NULL, pairLR.use = NULL,
                       sources.use = NULL, targets.use = NULL, thresh = 0.05) {
  if (is.null(net)) {
    prob <- slot(object, "net")$prob
    pval <- slot(object, "net")$pval
    prob[pval > thresh] <- 0
    net <- reshape2::melt(prob, value.name = "prob")
    colnames(net)[1:3] <- c("source", "target", "interaction_name")
    pairLR <- dplyr::select(object@LR$LRsig, c(
      "interaction_name_2",
      "pathway_name", "ligand", "receptor", "annotation",
      "evidence"
    ))
    idx <- match(net$interaction_name, rownames(pairLR))
    temp <- pairLR[idx, ]
    net <- cbind(net, temp)
  }
  if (!is.null(signaling)) {
    pairLR.use <- data.frame()
    for (i in 1:length(signaling)) {
      pairLR.use.i <- searchPair(
        signaling = signaling[i],
        pairLR.use = object@LR$LRsig, key = "pathway_name",
        matching.exact = T, pair.only = T
      )
      pairLR.use <- rbind(pairLR.use, pairLR.use.i)
    }
  }
  if (!is.null(pairLR.use)) {
    if ("interaction_name" %in% colnames(pairLR.use)) {
      net <- subset(net, interaction_name %in% pairLR.use$interaction_name)
    } else if ("pathway_name" %in% colnames(pairLR.use)) {
      net <- subset(net, pathway_name %in% as.character(pairLR.use$pathway_name))
    }
  }
  if (slot.name == "netP") {
    net <- dplyr::select(net, c(
      "source", "target", "pathway_name",
      "prob"
    ))
    net$source_target <- paste(net$source, net$target, sep = "sourceTotarget")
    net <- net %>%
      dplyr::group_by(source_target, pathway_name) %>%
      dplyr::summarize(prob = sum(prob))
    a <- stringr::str_split(net$source_target, "sourceTotarget",
                            simplify = T
    )
    net$source <- as.character(a[, 1])
    net$target <- as.character(a[, 2])
    net$ligand <- net$pathway_name
    net$receptor <- " "
  }
  if (!is.null(sources.use)) {
    if (is.numeric(sources.use)) {
      sources.use <- levels(object@idents)[sources.use]
    }
    net <- subset(net, source %in% sources.use)
  } else {
    sources.use <- levels(object@idents)
  }
  if (!is.null(targets.use)) {
    if (is.numeric(targets.use)) {
      targets.use <- levels(object@idents)[targets.use]
    }
    net <- subset(net, target %in% targets.use)
  } else {
    targets.use <- levels(object@idents)
  }
  df <- subset(net, prob > 0)
  if (nrow(df) == 0) {
    return(FALSE)
  } else {
    return(TRUE)
  }
}
#' Analyze interaction of Ligand-Receptors/LRs in pathways and plot results in batch.
#'
#' This function uses the "netVisual_bubble", "netVisual_chord_gene" and
#' "plotGeneExpression" function from CellChat to bar or circle plot to show
#' interaction of all LRs in each signaling pathway.
#'
#' @inheritParams PathInteracion
#' @param cell.source Cell types as sender of cell-cell communications.
#' @param cell.target Cell types as receiver of cell-cell communications.
#'
#' @importFrom CellChat netVisual_bubble
#' @importFrom CellChat netVisual_chord_gene
#' @importFrom CellChat plotGeneExpression
#'
#' @return Local pdf files.
#' @export
#'
LRsInteraction <- function(ct.obj, outdir, file.prefix = "Sample", cell.source = NULL, cell.target = NULL) {
  # - 1. general setting
  if (is.null(cell.source)) {
    stop("[Error] The cell.source is absent or empty !!!")
  }
  if (is.null(cell.target)) {
    stop("[Error] The cell.target is absent or empty !!!")
  }
  cell.db <- ct.obj@DB$interaction
  pathways.show <- unique(cell.db$pathway_name)
  cellchat.out <- paste0(outdir, "/LRs_interaction")
  if (!dir.exists(cellchat.out)) {
    dir.create(cellchat.out, recursive = T)
  }

  # - 2. LRs interaction of each pathway
  # all pathways
  out.p <- file.path(cellchat.out, paste0(file.prefix, "_all_significant_interactions_by_cell_groups_dot_plot.pdf"))
  pdf(out.p, width = 10, height = 30)
  print(netVisual_bubble(ct.obj,
                         sources.use = cell.source, targets.use = cell.target,
                         remove.isolate = FALSE, angle.x = 45
  ))
  dev.off()
  out.p <- file.path(cellchat.out, paste0(file.prefix, "_all_significant_interactions_by_cell_groups_chord_plot.pdf"))
  pdf(out.p, width = 20, height = 20)
  print(netVisual_chord_gene(ct.obj, sources.use = cell.source, targets.use = cell.target,
                             lab.cex = 0.5, legend.pos.y = 30))
  dev.off()
  # each pathway
  for (p in pathways.show) {
    path.exist <- p %in% unique(ct.obj@LR$LRsig$pathway_name)
    if (path.exist) {
      path.sig <- CheckLinks(
        object = ct.obj, sources.use = cell.source, targets.use = cell.target,
        signaling = p, thresh = 0.05, slot.name = "net", net = NULL, pairLR.use = NULL
      )
      if (isFALSE(path.sig)) {
        print("[Warning] Not found significant pathway")
      } else {
        out.p <- file.path(cellchat.out, paste0(file.prefix, "_", p, "_significant_interactions_by_cell_groups_chord_plot.pdf"))
        pdf(out.p, width = 8, height = 10)
        print(netVisual_chord_gene(ct.obj,
                                   sources.use = cell.source, targets.use = cell.target,
                                   signaling = p, lab.cex = 0.5, legend.pos.y = 30
        ))
        dev.off()
        out.p <- file.path(cellchat.out, paste0(file.prefix, "_", p, "_gene_expression_level_violin_plot.pdf"))
        pdf(out.p, width = 10, height = 8)
        print(plotGeneExpression(ct.obj, signaling = p))
        dev.off()
      }
    } else {
      print("[Warning] Not found pathway")
    }
  }
}
#' Analyze contributions of Ligand-Receptors/LRs in pathways and plot them in batch.
#'
#' This function uses the "netAnalysis_contribution" and "netVisual_individual"
#' functions from CellChat to draw bar or circle plot to show contribution of
#' all LRs in each signaling pathway.
#'
#' @inheritParams PathInteracion
#'
#' @importFrom CellChat netAnalysis_contribution
#' @importFrom CellChat extractEnrichedLR
#' @importFrom CellChat netVisual_individual
#'
#' @return Local pdf files.
#' @export
#'
LRsContribution <- function(ct.obj, outdir, file.prefix = "Sample") {
  # - 1. general setting
  cell.db <- ct.obj@DB$interaction
  pathways.show <- unique(cell.db$pathway_name)
  cellchat.out <- paste0(outdir, "/LRs_contribution")
  if (!dir.exists(cellchat.out)) {
    dir.create(cellchat.out, recursive = T)
  }

  # - 2. LRs contribution of each pathway
  for (p in pathways.show) {
    path.exist <- p %in% unique(ct.obj@LR$LRsig$pathway_name)
    if (isTRUE(path.exist)) {
      path.sig <- CheckPathway(ct.obj, signaling = p, thresh = 0.05)
    } else {
      path.sig <- FALSE
    }
    if (isTRUE(path.exist) & isTRUE(path.sig)) {
      out.p <- file.path(cellchat.out, paste0(file.prefix, "_", p, "_signaling_ligand_receptor_pair_contribution_plot.pdf"))
      pdf(out.p, width = 4, height = 5)
      print(netAnalysis_contribution(ct.obj, signaling = p))
      dev.off()
    } else {
      print("[Warning] Pathway not found or is not significant !!!")
    }
  }

  # - 3. circle plot of each LRs in each pathway
  pairPath <- c()
  for (p in pathways.show) {
    path.exist <- p %in% unique(ct.obj@LR$LRsig$pathway_name)
    if (path.exist) {
      path.sig <- CheckPathway(ct.obj, signaling = p, thresh = 0.05)
      if (isFALSE(path.sig)) {
        print("[Warning] Not found significant pathway")
      } else {
        pairPath <- append(pairPath, p)
      }
    } else {
      print("[Warning] Not found pathway")
    }
  }
  pairLR <- extractEnrichedLR(ct.obj, signaling = pairPath, geneLR.return = FALSE)
  for (i2 in seq(1, nrow(pairLR))) {
    LR.show <- pairLR[i2, ]
    out.p <- file.path(cellchat.out, paste0(file.prefix, "_", LR.show, "_ligand_receptor_pair_circle_plot.pdf"))
    pdf(out.p, width = 5, height = 5)
    print(netVisual_individual(ct.obj, signaling = unique(ct.obj@LR$LRsig$pathway_name), pairLR.use = LR.show, layout = "circle"))
    dev.off()
  }
}
#
netClustering.update <- function(object, slot.name = "netP",
                                 type = c("functional", "structural"),
                                 comparison = NULL, k = NULL, methods = "kmeans",
                                 do.plot = TRUE, fig.id = NULL, do.parallel = TRUE,
                                 nCores = 4, k.eigen = NULL) {
  type <- match.arg(type)
  if (object@options$mode == "single") {
    comparison <- "single"
    cat("Classification learning of the signaling networks for a single dataset",
        "\n")
  }
  else if (object@options$mode == "merged") {
    if (is.null(comparison)) {
      comparison <- 1:length(unique(object@meta$datasets))
    }
    cat("Classification learning of the signaling networks for datasets",
        as.character(comparison), "\n")
  }
  comparison.name <- paste(comparison, collapse = "-")
  Y <- methods::slot(object, slot.name)$similarity[[type]]$dr[[comparison.name]]
  data.use <- Y
  if (methods == "kmeans") {
    if (!is.null(k)) {
      clusters = kmeans(data.use, k, nstart = 10)$cluster
    }
    else {
      N <- nrow(data.use)
      kRange <- seq(2, min(N - 1, 10), by = 1)
      if (do.parallel) {
        #future::plan("multiprocess", workers = nCores)
        future::multisession(workers = nCores)
        options(future.globals.maxSize = 1000 * 1024^2)
      }
      my.sapply <- ifelse(test = future::nbrOfWorkers() ==
                            1, yes = pbapply::pbsapply, no = future.apply::future_sapply)
      results = my.sapply(X = 1:length(kRange), FUN = function(x) {
        idents <- kmeans(data.use, kRange[x], nstart = 10)$cluster
        clusIndex <- idents
        adjMat0 <- Matrix::Matrix(as.numeric(outer(clusIndex,
                                                   clusIndex, FUN = "==")), nrow = N, ncol = N)
        return(list(adjMat = adjMat0, ncluster = length(unique(idents))))
      }, simplify = FALSE)
      adjMat <- lapply(results, "[[", 1)
      CM <- Reduce("+", adjMat)/length(kRange)
      res <- computeEigengap(as.matrix(CM))
      numCluster <- res$upper_bound
      clusters = kmeans(data.use, numCluster, nstart = 10)$cluster
      if (do.plot) {
        gg <- res$gg.obj
        ggsave(filename = paste0("estimationNumCluster_",
                                 fig.id, "_", type, "_dataset_", comparison.name,
                                 ".pdf"), plot = gg, width = 3.5, height = 3,
               units = "in", dpi = 300)
      }
    }
  }
  else if (methods == "spectral") {
    A <- as.matrix(data.use)
    D <- apply(A, 1, sum)
    L <- diag(D) - A
    L <- diag(D^-0.5) %*% L %*% diag(D^-0.5)
    evL <- eigen(L, symmetric = TRUE)
    plot(rev(evL$values)[1:30])
    Z <- evL$vectors[, (ncol(evL$vectors) - k.eigen + 1):ncol(evL$vectors)]
    clusters = kmeans(Z, k, nstart = 20)$cluster
  }
  if (!is.list(methods::slot(object, slot.name)$similarity[[type]]$group)) {
    methods::slot(object, slot.name)$similarity[[type]]$group <- NULL
  }
  methods::slot(object, slot.name)$similarity[[type]]$group[[comparison.name]] <- clusters
  return(object)
}
