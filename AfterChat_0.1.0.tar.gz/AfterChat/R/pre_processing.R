#' Perform decoupleR analysis to infer transcription factor activity.
#'
#' This function computes transcription factor activity according using package
#' decoupleR. It return a scaled matrix (cells * TFs) that records the activity
#' of detected transcription factors.
#'
#' @param sr.obj A Seurat object.
#' @param species Species for DoRothEA, such as human or mouse.
#'
#' @importFrom decoupleR get_dorothea
#' @importFrom decoupleR run_wmean
#' @importFrom Seurat CreateAssayObject
#' @importFrom Seurat ScaleData
#' @importFrom Seurat DefaultAssay<-
#' @import dplyr
#' @import tibble
#' @import tidyr
#'
#' @return scaled matrix: cells * TFs.
#' @export
#'
#' @examples
#' library("decoupleR")
#' inputs_dir <- system.file("extdata", package = "decoupleR")
#' pbmc <- readRDS(file.path(inputs_dir, "sc_data.rds"))
#' data <- Pipe.decoupleR(sr.obj = pbmc, species = "human")
Pipe.decoupleR <- function(sr.obj, species) {
  # - 1. check parameters
  if (!(species %in% c("human", "mouse"))) {
    stop("[Error] For now, we only support human and mouse !!!")
  }

  # - 2. decoupleR: transcription factor activity inference
  # load DoRothEA network
  net <- get_dorothea(organism = species, levels = c("A", "B", "C", "D"))
  # extract the normalized log-transformed counts
  mat <- as.matrix(sr.obj@assays$RNA@data)
  # run wmean
  acts <- run_wmean(
    mat = mat, net = net, .source = "source", .target = "target",
    .mor = "mor", times = 100, minsize = 5
  )
  # load dat into seurat
  sr.obj[["tfswmean"]] <- acts %>%
    filter(statistic == "norm_wmean") %>%
    pivot_wider(
      id_cols = "source", names_from = "condition",
      values_from = "score"
    ) %>%
    column_to_rownames("source") %>%
    Seurat::CreateAssayObject(.)
  Seurat::DefaultAssay(sr.obj) <- "tfswmean"
  #sr.obj <- ScaleData(sr.obj)

  # - 3. return data
  mx.data <- sr.obj@assays$tfswmean@data %>%
    as.matrix() %>%
    t()
  return(mx.data)
}
#' Perform CellChat analysis without visualizing steps.
#'
#' This function enables you to easily perform CellChat analysis. But it doesn't
#' contain the steps involved with visualization. For now, it supports two types
#' of single cell data, including Seurat and SingleCellExperiment. It will output
#' one or more CellChat objects according to the setting of the split.by parameter.
#'
#' @param sc.obj A single cell object, including seurat or sce object.
#' @param cell.db Database in CellChat format, such as CellChatDB.human.
#' @param group.by A column name in metadata to group cells, such as cell types.
#' @param split.by A column name in metadata to split cells, such as treatment or NULL.
#' @param filter.data Logical: whether to filter cells.
#' @param filter.by A column name in cell metadata to filter cells, such as cell types.
#' @param filter.terms The interested terms to keep, such as a part of cell types.
#'
#' @importFrom SummarizedExperiment assay
#' @importFrom SingleCellExperiment colData
#' @importFrom Seurat CreateSeuratObject
#' @importFrom Seurat NormalizeData
#' @importFrom Seurat GetAssayData
#' @importFrom CellChat createCellChat
#' @importFrom CellChat subsetData
#' @importFrom CellChat identifyOverExpressedGenes
#' @importFrom CellChat identifyOverExpressedInteractions
#'
#' @return One or multiple CellChat objects.
#' @export
#'
#' @examples
#' library(Seurat)
#' library(CellChat)
#' Pipe.CellChat(sc.obj = pbmc_small, cell.db = CellChatDB.human,
#'               group.by = "letter.idents", split.by = NULL,
#'               filter.data = FALSE, filter.by = NULL, filter.terms = NULL)
Pipe.CellChat <- function(sc.obj, cell.db = NULL, group.by = NULL, split.by = NULL,
                          filter.data = FALSE, filter.by = NULL, filter.terms = NULL) {
  # - 1. check parameters
  if (!(class(sc.obj)[1] %in% c("Seurat", "SingleCellExperiment"))) {
    stop("[Error] The data type is not supported by this function !!!")
  }
  if (is.null(cell.db)) {
    stop("[Error] The database of cell-cell communication is Null !!!")
  }
  if (is.null(group.by)) {
    stop("[Error] You must provide cell information to group them !!!")
  }

  # - 2. create count table
  if (class(sc.obj)[1] == "SingleCellExperiment") {
    exprMat <- assay(sc.obj, "counts")
    cellInfo <- colData(sc.obj)
    sc.obj <- CreateSeuratObject(counts = exprMat, assay = "RNA", meta.data = cellInfo)
  }
  sc.obj <- NormalizeData(sc.obj)
  sc.obj$CellType <- sc.obj@meta.data[, group.by]
  if (isTRUE(filter.data)) {
    keep.cell <- sc.obj@meta.data[, filter.by] %in% filter.terms
    sc.obj <- sc.obj[, keep.cell]
  }
  cc.co <- GetAssayData(sc.obj, slot = "data") %>% as.matrix()

  # - 3. create metadata
  if (is.null(split.by)) {
    cc.meta <- sc.obj@meta.data %>% as.data.frame()
    cc.meta <- cc.meta[colnames(cc.co), ]
    cc.meta <- data.frame(id = rownames(cc.meta),
                          labels = cc.meta[, "CellType"],
                          row.names = rownames(cc.meta))
  } else {
    cc.meta <- sc.obj@meta.data %>% as.data.frame()
    cc.meta <- cc.meta[colnames(cc.co), ]
    cc.meta <- data.frame(id = rownames(cc.meta),
                          condition = cc.meta[, split.by],
                          labels = cc.meta[, "CellType"],
                          row.names = rownames(cc.meta))
  }

  # - 4. create CellChat object
  cc.ob <- list()
  if (is.null(split.by)) {
    cc.ob[[1]] <- createCellChat(object = cc.co, meta = cc.meta, group.by = "labels")
    cc.ob[[1]]@DB <- cell.db
    cc.ob[[1]] <- cc.ob[[1]] %>%
      subsetData() %>%
      identifyOverExpressedGenes() %>%
      identifyOverExpressedInteractions()
    names(cc.ob) <- c("Sample")
  } else {
    g <- cc.meta$condition %>% unique()
    for (i in seq(1, length(g))) {
      use.cell.meta <- subset(cc.meta, condition == g[i])
      cc.ob[[i]] <- createCellChat(object = cc.co[, use.cell.meta$id],
                                   meta = use.cell.meta, group.by = "labels")
      cc.ob[[i]]@DB <- cell.db
      cc.ob[[i]] <- cc.ob[[i]] %>%
        subsetData() %>%
        identifyOverExpressedGenes() %>%
        identifyOverExpressedInteractions()
      names(cc.ob)[i] <- g[i]
    }
  }
  return(cc.ob)
}
#' Convert single cell data to local loom file.
#'
#' This function can convert single cell object to loom file that can be used in
#' the calculation of TFs enrichment scores by SCENIC.
#'
#' @param sc.obj a single cell object, including seurat or sce object.
#' @param loom.file loom file name.
#'
#' @importFrom Seurat GetAssayData
#' @importFrom SummarizedExperiment assay
#' @importFrom SingleCellExperiment colData
#' @importFrom SCopeLoomR build_loom
#' @importFrom SCopeLoomR close_loom
#' @importFrom SCopeLoomR get_cell_ids
#' @importFrom SCENIC add_cell_annotation
#'
#' @return Local loom file.
#' @export
#'
#' @examples
#' library(Seurat)
#' WriteLoom(data = pbmc_small, loom.file = "~/test.loom")
#' test <- as.SingleCellExperiment(pbmc_small)
#' WriteLoom(data = test, loom.file = "~/test.loom")
WriteLoom <- function(sc.obj, loom.file) {
  # - 1. check parameters
  if (!(class(sc.obj)[1] %in% c("Seurat", "SingleCellExperiment"))) {
    stop("[Error] The data type is not supported by this function !!!")
  }

  # - 2. extract count matrix and cell information
  if (class(sc.obj)[1] == "Seurat") {
    exprMat <- GetAssayData(sc.obj, slot = "count")
    cellInfo <- sc.obj@meta.data
  } else if (class(sc.obj)[1] == "SingleCellExperiment") {
    exprMat <- assay(sc.obj, "counts")
    cellInfo <- colData(sc.obj)
  }

  # - 3. output loom
  loom <- build_loom(loom.file, dgem = exprMat)
  loom <- add_cell_annotation(loom, cellInfo)
  close_loom(loom)
}
#' Extract TF activity inferred by Signac.
#'
#' This function can extract TF activity from a seurat object, which was processed
#' by Signac pipeline. It supports the filtering function to keep cells you may
#' interest. The output is a matrix: cell * jaspar TFs motif id or name.
#'
#' @param sc.obj a seurat object processed by Signac.
#' @param filter.data Logical: whether to filter cells.
#' @param filter.by A column name in cell metadata to filter cells, such as cell types.
#' @param filter.terms The interested terms to keep, such as a part of cell types.
#' @param tf.format The colnames of output: jarpar TFs motif id or name.
#'
#' @importFrom Seurat GetAssayData
#'
#' @return a matrix: cell * jaspar TFs motif id or name.
#' @export
GetTfAct <- function(sc.obj, tf.format = "jaspar.id",
                     filter.data = FALSE, filter.by, filter.terms = NULL) {
  # - 1. check parameters
  if (class(sc.obj)[1] != "Seurat") {
    stop("[Error] Currently, the seurat data is only supported by this function!!!")
  }

  # - 2. filter cells
  if (isTRUE(filter.data)) {
    keep.cell <- sc.obj@meta.data[, filter.by] %in% filter.terms
    sc.obj <- sc.obj[, keep.cell]
  }

  # - 3. preprocess motif activity
  motif.anno <- unlist(sc.obj@assays$peaks@motifs@motif.names) %>%
    as.data.frame() %>%
    rownames_to_column(var = "id")
  colnames(motif.anno)[2] <- "symbol"
  motif.act <- GetAssayData(sc.obj, assay = "chromvar", slot = "data") %>%
    as.matrix()
  if (tf.format == "jaspar.id") {
    rownames(motif.act) <- motif.anno$id
  } else {
    rownames(motif.act) <- motif.anno$symbol
  }
  motif.act <- motif.act %>% t()

  # - 4. return motif activatity per cells
  all.res <- list(TFact = motif.act,
                  GroupInfo = sc.obj@meta.data[, filter.by])
  return(all.res)
}
