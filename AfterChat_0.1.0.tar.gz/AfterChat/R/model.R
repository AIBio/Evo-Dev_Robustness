#' Calculate the scale factors to adjust contact probability.
#'
#' This function uses the enrichment score of TFs to adjust of contact probability
#' inferred by CellChat package. It supports different algorithms for calculation
#' of normalization factors, including "mean", "median" and "ensembl average". The
#' scale factors are numeric values in the range 0-1 or zero-centered.
#'
#' @param tf.data Dataframe or matrix: cells * TFs.
#' @param ave.method Algorithms to calculate average TF activity.
#' @param scale.method Algorithms to scale average TF activity.
#' @param threshold A numeric value in the range 0-1.
#' @param genelist The gene names of TFs.
#' @param group.info A vector that records the group information, such as cell types.
#'
#' @return Normalization factors.
#' @export
#'
#' @examples
#' test <- matrix(1:100, nrow = 10)
#' colnames(test) <- head(LETTERS, 10)
#' group.info <- c(rep("a", 4), rep("b", 4), rep("c", 2))
#' genelist <- head(LETTERS, 3)
#' CalNormFactor(tf.data = test, ave.method = "all", genelist = genelist, group.info = group.info)
CalNormFactor <- function(tf.data, ave.method = "all", scale.data = TRUE,
                          scale.method = c("zero-center", "range-01"), threshold = NULL,
                          genelist = NULL, group.info = NULL) {
  # - 1. check parameters
  if (!(is.data.frame(tf.data) || is.matrix(tf.data))) {
    stop("[Error] The input data should be a datafram or matrix !!!")
  }
  if (!(ave.method %in% c("mean", "median", "ensembl", "all"))) {
    stop("[Error] The method is not supported by this function !!!")
  }
  if (is.null(genelist) | is.null(group.info)) {
    stop("[Error] The genes and cell group information must be provided !!!")
  }

  # - 2. scale TF activity
  if (scale.method == "zero-center") {
    data.scale <- apply(tf.data, 2, function(x) {
      (x - mean(x)) / sd(x)
    })
  } else if (scale.method == "range-01") {
    data.scale <- apply(tf.data, 2, function(x) {
      (x - min(x)) / (max(x) - min(x))
    })
  } else {
    stop("[Error] Unsupported scaling method !!!")
  }
  group.info.uniq <- unique(group.info)
  genelist <- intersect(genelist, colnames(tf.data))

  # - 3. calculate normalization factor
  nor.factor <- list(
    Mean = vector(),
    Median = vector(),
    Ensembl.Mean = vector()
  )
  for (i in group.info.uniq) {
    if (length(genelist) == 1) {
      norm.value <- data.scale[grep(i, group.info), genelist]
    } else {
      norm.value <- apply(
        data.scale[grep(i, group.info), genelist], 1,
        function(x) {
          1 / 2 * (unname(as.numeric(quantile(x)))[3]) +
            1 / 4 * (unname(as.numeric(quantile(x)))[2] + unname(as.numeric(quantile(x)))[4])
        }
      )
    }
    # mean
    nor.factor$Mean <- append(nor.factor$Mean, mean(norm.value))
    # median
    nor.factor$Median <- append(nor.factor$Median, median(norm.value))
    # ensembl mean
    tmp.factor <- 1 / 2 * (unname(as.numeric(quantile(norm.value)))[3]) +
      1 / 4 * (unname(as.numeric(quantile(norm.value)))[2] + unname(as.numeric(quantile(norm.value)))[4])
    nor.factor$Ensembl.Mean <- append(nor.factor$Ensembl.Mean, tmp.factor)
  }

  # - 4. scale normalization factor to 0-1
  nor.factor.scale <- list()
  for (i in 1:length(nor.factor)) {
    names(nor.factor[[i]]) <- group.info.uniq
    if (scale.method == "zero-center") {
      if (is.null(threshold)) {
        threshold <- 0
      }
      nor.factor.scale[[i]] <- (nor.factor[[i]] - mean(nor.factor[[i]])) / sd(nor.factor[[i]])
      nor.factor.scale[[i]][nor.factor.scale[[i]] < threshold] <- 0
      nor.factor.scale[[i]][nor.factor.scale[[i]] > threshold] <- 1
    } else if (scale.method == "range-01") {
      if (is.null(threshold)) {
        threshold <- 1 / 2 * (unname(as.numeric(quantile(nor.factor[[i]])))[3]) +
          1 / 4 * (unname(as.numeric(quantile(nor.factor[[i]])))[2] + unname(as.numeric(quantile(nor.factor[[i]])))[4])
      }
      nor.factor.scale[[i]] <- (nor.factor[[i]] - min(nor.factor[[i]])) / (max(nor.factor[[i]]) - min(nor.factor[[i]]))
      nor.factor.scale[[i]][nor.factor.scale[[i]] < threshold] <- 0
      nor.factor.scale[[i]][nor.factor.scale[[i]] > threshold] <- 1
    } else {
      stop("[Error] Unsupported scaling method !!!")
    }
  }
  names(nor.factor.scale) <- names(nor.factor)

  # - 5. output data
  if (isTRUE(scale.data)) {
    final.res <- nor.factor.scale
  } else {
    final.res <- nor.factor
  }
  if (ave.method == "mean") {
    return(final.res$Mean)
  } else if (ave.method == "median") {
    return(final.res$Median)
  } else if (ave.method == "ensembl") {
    return(final.res$Ensembl.Mean)
  } else if (ave.method == "all") {
    return(final.res)
  }
}
#' Calculate the contact probability and pvalue and normalized them.
#'
#' This function can compute probability and pvalue with same method used by
#' CellChat package. Meanwhile, it normalizes the probability and re-calculates
#' the pvalue in our interested pathway.
#'
#' @param ct.obj A CellChat object.
#' @param type A method to compute the average gene expression per cell group.
#' @param trim The fraction (0 to 0.25) of observations to be trimmed from each.
#'             end of x before the mean is computed.
#' @param scale.factor A list named by pathway names records scaling factors.
#' @param object Interested signaling pathway for normalization.
#' @param ... Same arguments with \code{\link[CellChat]{computeCommunProb}}.
#'
#' @importFrom CellChat aggregateNet
#' @importFrom CellChat computeCommunProbPathway
#' @importFrom CellChat computeExpr_LR
#' @importFrom CellChat computeExpr_coreceptor
#' @importFrom CellChat computeExpr_agonist
#' @importFrom future nbrOfWorkers
#' @importFrom future.apply future_sapply
#' @importFrom pbapply pbsapply
#' @importFrom stats aggregate
#' @importFrom Matrix crossprod
#' @importFrom utils txtProgressBar setTxtProgressBar
#'
#' @return CellChat object with scaled contact probability and pvalue.
#' @export
#'
AdjustProPval <- function(ct.obj, type = c("triMean", "truncatedMean", "median"), trim = 0.1,
                          scale.factor = NULL, scale.path = NULL,
                          LR.use = NULL, raw.use = TRUE, population.size = FALSE,
                          nboot = 100, seed.use = 1L, Kh = 0.5, n = 1) {
  # - 1. check parameters
  if (is.null(scale.factor)) {
    stop("[Error] The scale factor is absent or empty !!!")
  }
  if (!all(scale.path %in% ct.obj@LR$LRsig$pathway_name)) {
    stop("[Error] The pathway for normalization doesn't exist in your data !!!")
  }
  # - 2. general setting
  FunMean <- switch(type,
    triMean = triMean,
    truncatedMean = function(x) mean(x, trim = trim, na.rm = TRUE),
    median = function(x) median(x, na.rm = TRUE)
  )
  if (raw.use) {
    data <- as.matrix(ct.obj@data.signaling)
  } else {
    data <- ct.obj@data.project
  }
  if (is.null(LR.use)) {
    pairLR.use <- ct.obj@LR$LRsig
  } else {
    pairLR.use <- LR.use
  }
  # !!! define interaction to normalization
  pairLR.scale <- subset(ct.obj@LR$LRsig, pathway_name %in% scale.path)
  # keep going
  complex_input <- ct.obj@DB$complex
  cofactor_input <- ct.obj@DB$cofactor
  if (future::nbrOfWorkers() == 1) {
    my.sapply <- sapply
  } else {
    my.sapply <- future.apply::future_sapply
  }
  # my.sapply <- ifelse(test = future::nbrOfWorkers() == 1, yes = sapply,
  #                    no = future.apply::future_sapply)
  ptm <- Sys.time()
  pairLRsig <- pairLR.use
  group <- ct.obj@idents
  geneL <- as.character(pairLRsig$ligand)
  geneR <- as.character(pairLRsig$receptor)
  nLR <- nrow(pairLRsig)
  numCluster <- nlevels(group)
  if (numCluster != length(unique(group))) {
    stop("Please check `unique(ct.obj@idents)` and ensure that the factor levels are correct!\n
         You may need to drop unused levels using 'droplevels' function. e.g.,\n
         `meta$labels = droplevels(meta$labels, exclude = setdiff(levels(meta$labels),unique(meta$labels)))`")
  }
  data.use <- data / max(data)
  nC <- ncol(data.use)

  # - 3. compute probability and pvalue and normalize them
  data.use.avg <- aggregate(t(data.use), list(group), FUN = FunMean)
  data.use.avg <- t(data.use.avg[, -1])
  colnames(data.use.avg) <- levels(group)
  dataLavg <- computeExpr_LR(geneL, data.use.avg, complex_input)
  dataRavg <- computeExpr_LR(geneR, data.use.avg, complex_input)
  dataRavg.co.A.receptor <- computeExpr_coreceptor(cofactor_input,
    data.use.avg, pairLRsig,
    type = "A"
  )
  dataRavg.co.I.receptor <- computeExpr_coreceptor(cofactor_input,
    data.use.avg, pairLRsig,
    type = "I"
  )
  dataRavg <- dataRavg * dataRavg.co.A.receptor / dataRavg.co.I.receptor
  dataLavg2 <- t(replicate(nrow(dataLavg), as.numeric(table(group)) / nC))
  dataRavg2 <- dataLavg2
  index.agonist <- which(!is.na(pairLRsig$agonist) & pairLRsig$agonist != "")
  index.antagonist <- which(!is.na(pairLRsig$antagonist) & pairLRsig$antagonist != "")
  Prob <- array(0, dim = c(numCluster, numCluster, nLR))
  Pval <- array(0, dim = c(numCluster, numCluster, nLR))
  set.seed(seed.use)
  permutation <- replicate(nboot, sample.int(nC, size = nC))
  data.use.avg.boot <- my.sapply(X = 1:nboot, FUN = function(nE) {
    groupboot <- group[permutation[, nE]]
    data.use.avgB <- aggregate(t(data.use), list(groupboot),
      FUN = FunMean
    )
    data.use.avgB <- t(data.use.avgB[, -1])
    return(data.use.avgB)
  }, simplify = FALSE)
  pb <- txtProgressBar(min = 0, max = nLR, style = 3, file = stderr())
  for (i in 1:nLR) {
    dataLR <- Matrix::crossprod(matrix(dataLavg[i, ],
      nrow = 1
    ), matrix(dataRavg[i, ], nrow = 1))
    P1 <- dataLR^n / (Kh^n + dataLR^n)
    if (sum(P1) == 0) {
      Pnull <- P1
      Prob[, , i] <- Pnull
      p <- 1
      Pval[, , i] <- matrix(p,
        nrow = numCluster, ncol = numCluster,
        byrow = FALSE
      )
    } else {
      if (is.element(i, index.agonist)) {
        data.agonist <- computeExpr_agonist(
          data.use = data.use.avg,
          pairLRsig, cofactor_input, index.agonist = i,
          Kh = Kh, n = n
        )
        P2 <- Matrix::crossprod(matrix(data.agonist,
          nrow = 1
        ))
      } else {
        P2 <- matrix(1, nrow = numCluster, ncol = numCluster)
      }
      if (is.element(i, index.antagonist)) {
        data.antagonist <- computeExpr_antagonist(
          data.use = data.use.avg,
          pairLRsig, cofactor_input, index.antagonist = i,
          Kh = Kh, n = n
        )
        P3 <- Matrix::crossprod(matrix(data.antagonist,
          nrow = 1
        ))
      } else {
        P3 <- matrix(1, nrow = numCluster, ncol = numCluster)
      }
      if (population.size) {
        P4 <- Matrix::crossprod(matrix(dataLavg2[i, ], nrow = 1), matrix(dataRavg2[i, ], nrow = 1))
      } else {
        P4 <- matrix(1, nrow = numCluster, ncol = numCluster)
      }
      Pnull <- P1 * P2 * P3 * P4
      # !!! scale observed probability of interested pathway
      if (pairLRsig[i, ]$pathway_name %in% scale.path) {
        if (!all(levels(group) %in% names(scale.factor[[pairLRsig[i, ]$pathway_name]]))) {
          stop("[Error] Scaling factors for some cells are absent !!!")
        }
        Pnull <- Pnull * rep(scale.factor[[pairLRsig[i, ]$pathway_name]][levels(group)], each = numCluster)
      }
      # keep going
      Prob[, , i] <- Pnull
      Pnull <- as.vector(Pnull)
      Pboot <- sapply(X = 1:nboot, FUN = function(nE) {
        data.use.avgB <- data.use.avg.boot[[nE]]
        dataLavgB <- computeExpr_LR(
          geneL[i], data.use.avgB,
          complex_input
        )
        dataRavgB <- computeExpr_LR(
          geneR[i], data.use.avgB,
          complex_input
        )
        dataRavgB.co.A.receptor <- computeExpr_coreceptor(cofactor_input,
          data.use.avgB, pairLRsig[i, , drop = FALSE],
          type = "A"
        )
        dataRavgB.co.I.receptor <- computeExpr_coreceptor(cofactor_input,
          data.use.avgB, pairLRsig[i, , drop = FALSE],
          type = "I"
        )
        dataRavgB <- dataRavgB * dataRavgB.co.A.receptor / dataRavgB.co.I.receptor
        dataLRB <- Matrix::crossprod(dataLavgB, dataRavgB)
        P1.boot <- dataLRB^n / (Kh^n + dataLRB^n)
        if (is.element(i, index.agonist)) {
          data.agonist <- computeExpr_agonist(
            data.use = data.use.avgB,
            pairLRsig, cofactor_input, index.agonist = i,
            Kh = Kh, n = n
          )
          P2.boot <- Matrix::crossprod(matrix(data.agonist,
            nrow = 1
          ))
        } else {
          P2.boot <- matrix(1, nrow = numCluster, ncol = numCluster)
        }
        if (is.element(i, index.antagonist)) {
          data.antagonist <- computeExpr_antagonist(
            data.use = data.use.avgB,
            pairLRsig, cofactor_input, index.antagonist = i,
            Kh = Kh, n = n
          )
          P3.boot <- Matrix::crossprod(matrix(data.antagonist,
            nrow = 1
          ))
        } else {
          P3.boot <- matrix(1, nrow = numCluster, ncol = numCluster)
        }
        if (population.size) {
          groupboot <- group[permutation[, nE]]
          dataLavg2B <- as.numeric(table(groupboot)) / nC
          dataLavg2B <- matrix(dataLavg2B, nrow = 1)
          dataRavg2B <- dataLavg2B
          P4.boot <- Matrix::crossprod(dataLavg2B, dataRavg2B)
        } else {
          P4.boot <- matrix(1, nrow = numCluster, ncol = numCluster)
        }
        Pboot <- P1.boot * P2.boot * P3.boot * P4.boot
        return(as.vector(Pboot))
      })
      # calculate pvalue
      Pboot <- matrix(unlist(Pboot),
        nrow = length(Pnull),
        ncol = nboot, byrow = FALSE
      )
      # !!! scale expected probability of interested pathway
      if (pairLRsig[i, ]$pathway_name %in% scale.path) {
        if (!all(levels(group) %in% names(scale.factor[[pairLRsig[i, ]$pathway_name]]))) {
          stop("[Error] Scaling factors for some cells are absent !!!")
        }
        Pboot <- Pboot * rep(scale.factor[[pairLRsig[i, ]$pathway_name]][levels(group)], each = numCluster)
      }
      # keep going
      nReject <- rowSums(Pboot - Pnull >= 0)
      p <- nReject / nboot
      Pval[, , i] <- matrix(p,
        nrow = numCluster, ncol = numCluster,
        byrow = FALSE
      )
    }
    setTxtProgressBar(pb = pb, value = i)
  }
  close(con = pb)

  # - 4. return scaled data
  Pval[Prob == 0] <- 1
  dimnames(Prob) <- list(levels(group), levels(group), rownames(pairLRsig))
  dimnames(Pval) <- dimnames(Prob)
  net <- list(prob = Prob, pval = Pval)
  execution.time <- Sys.time() - ptm
  ct.obj@options$run.time <- as.numeric(execution.time, units = "secs")
  ct.obj@options$parameter <- list(
    type.mean = type, trim = trim,
    raw.use = raw.use, population.size = population.size,
    nboot = nboot, seed.use = seed.use, Kh = Kh, n = n
  )
  ct.obj@net <- net
  ct.obj <- computeCommunProbPathway(ct.obj) %>% aggregateNet()
  return(ct.obj)
}
